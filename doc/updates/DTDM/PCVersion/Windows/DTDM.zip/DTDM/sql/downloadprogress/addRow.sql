INSERT INTO dtdmdownloadProgress
(
	userEmail,
	userUName,
	userPwd,
	userApp,
	userAccess
)
VALUES
(
	:userEmail,
	:userUName,
	:userPwd,
	:userApp,
	:userAccess
)