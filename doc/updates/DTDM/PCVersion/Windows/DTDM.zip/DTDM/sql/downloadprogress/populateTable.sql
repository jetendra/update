INSERT INTO dtdmdownloadProgress
(
	userEmail,
	userUName,
	userPwd,
	userApp,
	userAccess
)
SELECT 'abc@xyz.com', 'admin', '12345678', '1', 'admin' UNION
SELECT 'abc1@xyz.com', 'abc1', '12345678', '1', 'user' UNION
SELECT 'abc2@xyz.com', 'abc2', '12345678', '1', 'user'