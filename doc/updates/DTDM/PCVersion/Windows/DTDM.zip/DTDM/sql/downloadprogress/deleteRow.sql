DELETE FROM dtdmdownloadProgress
WHERE id = :id