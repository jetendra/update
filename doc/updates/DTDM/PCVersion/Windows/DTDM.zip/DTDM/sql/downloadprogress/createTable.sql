﻿CREATE TABLE dtdmdownloadProgress
(
	id int PRIMARY KEY AUTOINCREMENT,
	userEmail String NOT NULL,
	userUName String NOT NULL,
	userPwd String NOT NULL,
	userApp String,
	userAccess String NOT NULL
)