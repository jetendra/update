UPDATE dtdmdownloadProgress
SET userEmail = :userEmail,
	userUName = :userUName,
	userPwd = :userPwd,
	userApp = :userApp,
	userAccess = :userAccess
WHERE id = :id